import 'package:flutter/material.dart';
import 'package:warung_santai/model/post.dart';

class PostView extends StatelessWidget {
  final Post post;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  const PostView({
    super.key,
    required this.post,
    this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Image.network(
          post.image,
          height: 150,
          width: 150,
          fit: BoxFit.cover,
        ),
        const SizedBox(
          width: 16,
        ),
        Expanded(
          flex: 3,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                post.title,
                maxLines: 1,
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              Text(post.content),
            ],
          ),
        )
      ],
    );
  }
}
