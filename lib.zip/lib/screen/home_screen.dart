import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:warung_santai/model/food_item.dart';
import 'food_details_screen.dart';

class HomeScreen extends StatelessWidget {
  final List<Map<String, String>> categories = [
    {'name': 'Breakfast', 'image': 'assets/bx-egg-fried.png'},
    {'name': 'Nasi', 'image': 'assets/bx-bowl-rice.png'},
    {'name': 'Gorengan', 'image': 'assets/bx-taco.png'},
    {'name': 'Minuman', 'image': 'assets/bx-coffee-cup.png'},
    {'name': 'Camilan', 'image': 'assets/bx-icecream.png'},
  ];

  final List<Map<String, dynamic>> popularItems = [
    {'name': 'Nasi Goreng', 'image': 'assets/nasgor.jpg', 'price': 15000},
    {'name': 'Batagor', 'image': 'assets/batagor.jpg', 'price': 10000},
  ];

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          'assets/menu.png', // Pastikan nama file sesuai
          fit: BoxFit.cover,
          height: double.infinity,
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Greeting
                    Text(
                      'Selamat Datang di Warung Santai!',
                      style: GoogleFonts.poppins(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                    SizedBox(height: 20),
                    // Search Bar
                    TextField(
                      decoration: InputDecoration(
                        hintText: 'Cari makanan favoritmu...',
                        prefixIcon:
                            Icon(Icons.search, color: Colors.green[700]),
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(25)),
                      ),
                    ),
                    SizedBox(height: 20),
                    // Categories
                    Text(
                      'Kategori Makanan',
                      style: GoogleFonts.poppins(
                          fontSize: 18, color: Colors.black),
                    ),
                    SizedBox(
                      height: 130, // Diperluas sedikit untuk akomodasi teks
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: categories.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisSize: MainAxisSize
                                  .min, // Menggunakan ukuran minimum
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: Image.asset(
                                    categories[index]['image']!,
                                    width: 40,
                                    height: 40,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(height: 5),
                                Flexible(
                                  // Membuat teks fleksibel
                                  child: Text(
                                    categories[index]['name']!,
                                    style: TextStyle(color: Colors.white),
                                    overflow: TextOverflow
                                        .ellipsis, // Potong teks panjang
                                    maxLines: 1,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    SizedBox(height: 20),
                    // Popular Items
                    Text(
                      'Makanan Populer',
                      style: GoogleFonts.poppins(
                          fontSize: 18, color: Colors.black),
                    ),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: popularItems.length,
                      itemBuilder: (context, index) {
                        return Card(
                          color: Colors.brown[100],
                          margin: EdgeInsets.symmetric(vertical: 10),
                          child: ListTile(
                            leading: Image.asset(popularItems[index]['image']!,
                                width: 60, height: 60, fit: BoxFit.cover),
                            title: Text(popularItems[index]['name']!,
                                style: TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text(
                                'Rp. ${popularItems[index]['price']}',
                                style: TextStyle(color: Colors.green[700])),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => FoodDetailsScreen(
                                    foodItem: FoodItem(
                                      id: index.toString(),
                                      name: popularItems[index]['name']!,
                                      description:
                                          'Delicious ${popularItems[index]['name']}!',
                                      price: popularItems[index]['price']
                                          .toDouble(),
                                      imageUrl: popularItems[index]['image']!,
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      },
                    ),
                    // Recommended Items
                    Text(
                      'Rekomendasi untukmu',
                      style: GoogleFonts.poppins(
                          fontSize: 18, color: Colors.black),
                    ),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: popularItems.length,
                      itemBuilder: (context, index) {
                        return Card(
                          color: Colors.brown[100],
                          margin: EdgeInsets.symmetric(vertical: 10),
                          child: ListTile(
                            leading: Image.asset(popularItems[index]['image']!,
                                width: 60, height: 60, fit: BoxFit.cover),
                            title: Text(popularItems[index]['name']!,
                                style: TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text(
                                'Rp. ${popularItems[index]['price']}',
                                style: TextStyle(color: Colors.green[700])),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => FoodDetailsScreen(
                                    foodItem: FoodItem(
                                      id: index.toString(),
                                      name: popularItems[index]['name']!,
                                      description:
                                          'Delicious ${popularItems[index]['name']}!',
                                      price: popularItems[index]['price']
                                          .toDouble(),
                                      imageUrl: popularItems[index]['image']!,
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
