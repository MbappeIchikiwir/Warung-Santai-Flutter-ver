import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/post_provider.dart';
import '../component/post_view.dart';
import '../screen/add_edit_post_screen.dart';
import '../model/post.dart';

class HomeAdmin extends StatefulWidget {
  final String title;

  const HomeAdmin({
    super.key,
    required this.title,
  });

  @override
  State<HomeAdmin> createState() => _HomeAdminState();
}

class _HomeAdminState extends State<HomeAdmin> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<PostProvider>().fetchPosts();
    });
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        context.read<PostProvider>().loadMorePosts();
      }
    });
  }

  void _addPost() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AddEditPostScreen()),
    ).then((result) {
      if (result == true) {
        context.read<PostProvider>().fetchPosts(page: 1);
      }
    });
  }

  void _editPost(Post post) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AddEditPostScreen(post: post)),
    ).then((result) {
      if (result == true) {
        context.read<PostProvider>().fetchPosts(page: 1);
      }
    });
  }

  void _deletePost(Post post) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Post'),
        content: const Text('Are you sure you want to delete this post?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final success = await context.read<PostProvider>().deletePost(post.id);
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Post deleted successfully')),
        );
        context.read<PostProvider>().fetchPosts(page: 1);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to delete post')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: _buildPostList(),
      floatingActionButton: FloatingActionButton(
        onPressed: _addPost,
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildPostList() {
    return Consumer<PostProvider>(
      builder: (context, postProvider, child) {
        final posts = postProvider.posts;
        final hasNextPage = postProvider.hasNextPage;

        return ListView.builder(
          controller: _scrollController,
          itemCount: posts.length + (hasNextPage ? 1 : 0),
          itemBuilder: (context, index) {
            if (index == posts.length) {
              return const Center(child: CircularProgressIndicator());
            }
            final post = posts[index];

            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card.filled(
                clipBehavior: Clip.hardEdge,
                child: InkWell(
                  onTap: () {
                    // Todo action ke detail post
                  },
                  child: Stack(
                    children: [
                      PostView(post: post),
                      Positioned(
                        top: 2,
                        right: 2,
                        child: IconButton(
                          onPressed: () => _editPost(post),
                          icon: const Icon(Icons.edit_rounded),
                        ),
                      ),
                      Positioned(
                        bottom: 2,
                        right: 2,
                        child: IconButton(
                          onPressed: () => _deletePost(post),
                          icon: const Icon(Icons.delete_rounded),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}
