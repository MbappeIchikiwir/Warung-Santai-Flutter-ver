import 'package:flutter/material.dart';

class AuthProvider with ChangeNotifier {
  bool _isAuthenticated = false;
  String? _userEmail;
  String? _userName;

  bool get isAuthenticated => _isAuthenticated;
  String? get userEmail => _userEmail;
  String? get userName => _userName;

  void login(String email, String password) {
    // Implement login logic here
    // For now, we'll just simulate a successful login
    _isAuthenticated = true;
    _userEmail = email;
    _userName = email.split('@')[0]; // Simple username extraction
    notifyListeners();
  }

  void register(String name, String email, String password, String phone) {
    // Implement registration logic here
    // For now, we'll just simulate a successful registration
    _isAuthenticated = true;
    _userEmail = email;
    _userName = name;
    notifyListeners();
  }

  void logout() {
    _isAuthenticated = false;
    _userEmail = null;
    _userName = null;
    notifyListeners();
  }

  // Optional: Add methods for password reset, email verification, etc.
  void resetPassword(String email) {
    // Implement password reset logic
    print('Password reset requested for: $email');
  }

  // Optional: Check if user is logged in on app start
  bool checkAuthStatus() {
    // You can implement logic to check if user was previously logged in
    // using shared preferences or other storage
    return _isAuthenticated;
  }
}
